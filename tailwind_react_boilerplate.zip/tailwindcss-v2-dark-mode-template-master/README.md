# TailwindCSS Dark Mode Template

This is a boilerplate template built with official features from TailwindCSS version 2.0.

This project was generated using Create React App and Tailwind was implemented using the [offical documentation found here](https://tailwindcss.com/docs/guides/create-react-app).

For an explaination on how this template works, read the rundown.

For full documentation, visit [tailwindcss.com](https://tailwindcss.com/docs/dark-mode).

![Tailwind Dark Mode Template](https://media.giphy.com/media/hEinaxjPrhQGffoW3z/giphy.gif)
