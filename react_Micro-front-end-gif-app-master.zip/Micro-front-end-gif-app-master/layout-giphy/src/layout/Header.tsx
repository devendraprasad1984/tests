import React from "react";
// type Props = {};

export default function Header(){
  return (
    <div className="flex flex-row justify-center p-3">
        <h1 className="text-4xl font-bold">Top trending gifs</h1>
    </div>
  );
};

