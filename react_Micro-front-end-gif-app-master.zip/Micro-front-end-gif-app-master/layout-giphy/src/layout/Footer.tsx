import React from "react"
// type Props = {};

export default function Footer(){
  return (
    <>
      <div className="flex flex-row justify-center p-3">
        <p className="text-2xl font-bold">&copy; 2022 Top trending gifs</p>
      </div>
    </>
  );
};

